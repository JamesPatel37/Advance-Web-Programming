package springmvc.model.dao;

import java.util.List;

import springmvc.model.Department;

public interface DepartmentDao {

	 Department getDepartment( long deptId );
	
	 List<Department> getDepartments();
	 
	 Department saveDepartment( Department department);

}
