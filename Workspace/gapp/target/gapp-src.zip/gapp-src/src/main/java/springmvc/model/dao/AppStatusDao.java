package springmvc.model.dao;

import java.util.List;

import springmvc.model.AppStatus;

public interface AppStatusDao {

	AppStatus getAppStatus( Integer id );

	 List<AppStatus> getAppStatus();

	 AppStatus saveAppStatus( AppStatus appStatus);
	 
}
