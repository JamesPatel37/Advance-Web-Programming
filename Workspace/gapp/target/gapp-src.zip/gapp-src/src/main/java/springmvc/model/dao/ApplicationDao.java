package springmvc.model.dao;

import java.util.List;

import springmvc.model.Application;
import springmvc.model.Users;

public interface ApplicationDao {

	Application getApplications( long appId );

	 List<Application> getApplications();

	List<Application> getApplicationByUserId(Users user);
	
	Application saveApplication(Application app);

}
