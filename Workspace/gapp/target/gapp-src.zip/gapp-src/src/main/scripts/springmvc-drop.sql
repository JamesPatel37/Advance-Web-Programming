drop table authorities;
drop table departments;
drop table users;

drop sequence hibernate_sequence;